package com.ticketapplication.springwebapp.controllers;

import com.ticketapplication.springwebapp.models.Customer;
import com.ticketapplication.springwebapp.repositories.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SignupController {
    @Autowired
    private CustomerRepository customerRepository;

    @GetMapping("/signup")
    public String displaySignup(final Customer customer) {
        return "signup";
    }

    @PostMapping("/signup")
    public String signupSubmit(final Customer customer) {
        try {
           customerRepository.save(customer);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/homepage";
    }
}
