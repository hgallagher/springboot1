package com.ticketapplication.springwebapp.controllers;

import com.ticketapplication.springwebapp.models.Agent;
import com.ticketapplication.springwebapp.models.Application;
import com.ticketapplication.springwebapp.models.Manager;
import com.ticketapplication.springwebapp.models.User;
import com.ticketapplication.springwebapp.repositories.AgentRepository;
import com.ticketapplication.springwebapp.repositories.ApplicationRepository;
import com.ticketapplication.springwebapp.repositories.ManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AdminController {

    @Autowired
    private ManagerRepository managerRepository;

    @Autowired
    private AgentRepository agentRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @GetMapping("/admin/homepage")
    public String goAdminHomepage(Model model) {
        model.addAttribute("managers", managerRepository.findAll());
        model.addAttribute("agents", agentRepository.findAll());
        model.addAttribute("apps", applicationRepository.findAll());
        return "adminpage";
    }

    @PostMapping("/admin/homepage")
    public String displayAdmin(Model model,
                               @ModelAttribute("adminlogin") Object adminlogin,
                               @ModelAttribute("managers") Object managers,
                               @ModelAttribute("agents") Object agents) {
        model.addAttribute("adminlogin", adminlogin);
        model.addAttribute("managers", managers);
        model.addAttribute("agents", agents);
        model.addAttribute("apps", applicationRepository.findAll());
        return "adminpage";
    }

    @GetMapping("/admin/add/manager")
    public String displayAddManagerPage(Model model) {
        model.addAttribute("accountForm", new User());
        return "addmanagerpage";
    }

    @PostMapping("/admin/add/manager/finish")
    public String addNewManager(@ModelAttribute("accountForm") User user, Model model) {

        Manager manangerAccount = new Manager(user.getUsername(), user.getPassword());
        managerRepository.save(manangerAccount);

        model.addAttribute("managers", managerRepository.findAll());
        model.addAttribute("agents", agentRepository.findAll());
        model.addAttribute("apps", applicationRepository.findAll());
        return "adminpage";
    }

    @GetMapping("/admin/add/agent")
    public String displayAddAgentPage(Model model) {
        model.addAttribute("accountForm", new Agent());
        model.addAttribute("managers", managerRepository.findAll());
        return "addagentpage";
    }

    @PostMapping("/admin/add/agent/finish")
    public String addNewAgent(@ModelAttribute("accountForm") Agent agent, Model model) {

        Agent agentAccount = new Agent(agent.getUsername(), agent.getPassword(), agent.getManager());
        agentRepository.save(agentAccount);

        model.addAttribute("managers", managerRepository.findAll());
        model.addAttribute("agents", agentRepository.findAll());
        model.addAttribute("apps", applicationRepository.findAll());
        return "adminpage";
    }

    @GetMapping("/admin/agent/delete/{id}")
    public String deleteAgent(@PathVariable("id") Long id, Model model) {
        Agent agent = agentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid agent Id:" + id));


        agentRepository.delete(agent);
        model.addAttribute("managers", managerRepository.findAll());
        model.addAttribute("agents", agentRepository.findAll());
        model.addAttribute("apps", applicationRepository.findAll());
        return "adminpage";
    }

    @GetMapping("/admin/manager/delete/{id}")
    public String deleteManager(@PathVariable("id") Long id, Model model) {
        Manager manager = managerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid manager Id:" + id));

        managerRepository.delete(manager);
        model.addAttribute("managers", managerRepository.findAll());
        model.addAttribute("agents", agentRepository.findAll());
        return "adminpage";
    }

    @GetMapping("/admin/add/application")
    public String displayAddApplicationPage(Model model) {
        model.addAttribute("appliForm", new Application());
        return "addapplicationpage";
    }

    @PostMapping("/admin/add/application/finish")
    public String addNewApplication(@ModelAttribute("appliForm") Application application, Model model) {

        Application applicationCreated = new Application(application.getName());
        applicationRepository.save(applicationCreated);

        model.addAttribute("managers", managerRepository.findAll());
        model.addAttribute("agents", agentRepository.findAll());
        model.addAttribute("apps", applicationRepository.findAll());
        return "adminpage";
    }

    @GetMapping("/admin/application/delete/{id}")
    public String deleteApplication(@PathVariable("id") Long id, Model model) {
        Application application = applicationRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid application Id:" + id));

        applicationRepository.delete(application);
        model.addAttribute("managers", managerRepository.findAll());
        model.addAttribute("agents", agentRepository.findAll());
        model.addAttribute("apps", applicationRepository.findAll());
        return "adminpage";
    }
}
