package com.ticketapplication.springwebapp.controllers;

import com.ticketapplication.springwebapp.models.Application;
import com.ticketapplication.springwebapp.models.Manager;
import com.ticketapplication.springwebapp.repositories.AgentRepository;
import com.ticketapplication.springwebapp.repositories.ApplicationRepository;
import com.ticketapplication.springwebapp.repositories.ManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ManagerController {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private ManagerRepository managerRepository;

    @Autowired
    private AgentRepository agentRepository;

    @GetMapping("/manager/homepage")
    public String displayManagerHomepage(@ModelAttribute("managerlogin") Manager managerlogin,
                                         Model model) {

        model.addAttribute("managerlogin", managerlogin);
        model.addAttribute("apps", applicationRepository.findAll());
        model.addAttribute("agents", agentRepository.findAll());
        return "managerpage";
    }

    @GetMapping("/manager/add/application")
    public String displayAddApplicationPage(@RequestParam Long managerId,
                                            Model model) {

        Manager manager = managerRepository.findById(managerId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid manager Id:" + managerId));


        model.addAttribute("appliForm", new Application());
        model.addAttribute("managerlogin", manager);
        return "addapplicationpagemanager";
    }

    @PostMapping("/manager/add/application/finish")
    public String addNewApplication(@ModelAttribute("appliForm") Application application,
                                    @RequestParam Long managerId,
                                    RedirectAttributes ra) {

        Application applicationCreated = new Application(application.getName());
        applicationRepository.save(applicationCreated);

        Manager manager = managerRepository.findById(managerId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid manager Id:" + managerId));

        ra.addFlashAttribute("managerlogin", manager);
        return "redirect:/manager/homepage";
    }

    @GetMapping("/manager/application/delete")
    public String deleteApplication(@RequestParam Long managerId,
                                    @RequestParam Long applicationId,
                                    RedirectAttributes ra) {

        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid application Id:" + applicationId));

        Manager manager = managerRepository.findById(managerId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid manager Id:" + managerId));

        applicationRepository.delete(application);
        ra.addFlashAttribute("managerlogin", manager);

        return "redirect:/manager/homepage";
    }
}
