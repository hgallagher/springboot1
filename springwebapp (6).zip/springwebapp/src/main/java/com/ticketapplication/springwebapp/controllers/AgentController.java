package com.ticketapplication.springwebapp.controllers;

import com.ticketapplication.springwebapp.models.Agent;
import com.ticketapplication.springwebapp.models.Resolution;
import com.ticketapplication.springwebapp.models.Ticket;
import com.ticketapplication.springwebapp.repositories.AgentRepository;
import com.ticketapplication.springwebapp.repositories.ApplicationRepository;
import com.ticketapplication.springwebapp.repositories.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AgentController {
    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private AgentRepository agentRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @GetMapping("/agent/homepage")
    public String goAgentHomepage(Model model,
                                  @ModelAttribute("agentlogin") Object agentlogin) {

        model.addAttribute("agentlogin", agentlogin);
        model.addAttribute("tickets", ticketRepository.findAll());
        return "agentpage";
    }

    @PostMapping("/agent/homepage")
    public String displayAdmin(Model model) {
        return "agentpage";
    }

    @GetMapping("/agent/take/ticket")
    public String takeTicket(@RequestParam Long ticketId,
                             @RequestParam Long agentId,
                             RedirectAttributes ra) {

        Ticket ticketTaken = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid ticket Id:" + ticketId));

        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid agent Id:" + agentId));

        ticketTaken.setAgent(agent);
        agent.getTickets().add(ticketTaken);

        ticketRepository.save(ticketTaken);
        agentRepository.save(agent);

        ra.addFlashAttribute("agentlogin", agent);

        return "redirect:/agent/homepage";
    }

    @GetMapping("/agent/free/ticket")
    public String freeTicket(@RequestParam Long ticketId,
                             @RequestParam Long agentId,
                             RedirectAttributes ra) {

        Ticket ticketNeedToFree = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid ticket Id:" + ticketId));

        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid agent Id:" + agentId));

        ticketNeedToFree.setAgent(null);
        agent.getTickets().remove(ticketNeedToFree);

        ticketRepository.save(ticketNeedToFree);
        agentRepository.save(agent);

        ra.addFlashAttribute("agentlogin", agent);

        return "redirect:/agent/homepage";
    }

    @GetMapping("/agent/resolve/ticket")
    public String displayResolveTicketPage(@RequestParam Long ticketId,
                                           @RequestParam Long agentId,
                                           Model model) {

        Ticket ticketNeedToResolve = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid ticket Id:" + ticketId));

        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid agent Id:" + agentId));

        model.addAttribute("ticket", ticketNeedToResolve);
        model.addAttribute("agentlogin", agent);
        model.addAttribute("resolution", new Resolution());
        return "resolveticketpage";
    }

    @PostMapping("/agent/resolve/ticket/finish")
    public String resolveTicket(@RequestParam Long ticketId,
                                @RequestParam Long agentId,
                                @ModelAttribute("resolution") Resolution resolution,
                                RedirectAttributes ra) {

        Ticket ticketResolved = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid ticket Id:" + ticketId));

        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid agent Id:" + agentId));

        System.out.println(resolution.getComment());
        System.out.println(resolution.getDate());

        ticketResolved.setResolution(resolution);
        resolution.setTicket(ticketResolved);

        ticketResolved.setAgent(agent);
        agent.getTickets().add(ticketResolved);

        ticketRepository.save(ticketResolved);
        agentRepository.save(agent);

        ra.addFlashAttribute("agentlogin", agent);

        return "redirect:/agent/homepage";
    }
}
