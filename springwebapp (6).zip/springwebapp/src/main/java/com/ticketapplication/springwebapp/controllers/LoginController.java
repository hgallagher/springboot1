package com.ticketapplication.springwebapp.controllers;

import com.ticketapplication.springwebapp.models.*;
import com.ticketapplication.springwebapp.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LoginController {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private ManagerRepository managerRepository;

    @Autowired
    private AgentRepository agentRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private TicketRepository ticketRepository;

    // Customer login controller
    @GetMapping("/customer")
    public String displayLoginAsCustomer(@ModelAttribute("customer") Customer customer) {
        return "logincustomer";
    }

    @PostMapping("/customer")
    public String loginAsCustomer(@ModelAttribute("customer")Customer customer, RedirectAttributes ra) {
        Customer customerLogin = customerRepository.findByUsernameAndPassword(customer.getUsername(), customer.getPassword());
        ra.addFlashAttribute("customerlogin", customerLogin);
        return "redirect:/homepage";
    }

    // Manager login controller
    @GetMapping("/login/manager")
    public String displayLoginAsManager(@ModelAttribute("manager") Manager manager) {
        return "loginmanager";
    }

    @PostMapping("/login/manager")
    public String loginAsManager(@ModelAttribute("manager") Manager manager,
                                 RedirectAttributes ra) {
        Manager managerLogin = managerRepository.findByUsernameAndPassword(manager.getUsername(), manager.getPassword());

        try {
            if (managerLogin == null) {
                return "loginmanager";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        ra.addFlashAttribute("managerlogin", managerLogin);

        return "redirect:/manager/homepage";
    }

    // Admin login controller
    @GetMapping("/login/admin")
    public String displayLoginAsAdmin(@ModelAttribute("admin") Admin admin) {
        return "loginadmin";
    }

    @PostMapping("/login/admin")
    public String loginAsAdmin(@ModelAttribute("admin") Admin admin, RedirectAttributes ra) {
        Admin adminLogin = adminRepository.findByUsernameAndPassword(admin.getUsername(), admin.getPassword());

        try {
            if (adminLogin == null) {
                return "loginadmin";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        ra.addFlashAttribute("adminlogin", adminLogin);
        ra.addFlashAttribute("managers", managerRepository.findAll());
        ra.addFlashAttribute("agents", agentRepository.findAll());
        return "redirect:/admin/homepage";
    }

    // Agent login controller
    @GetMapping("/login/agent")
    public String displayLoginAsAgent(Model model) {
        model.addAttribute("agent", new Agent());
        return "loginagent";
    }

    @PostMapping("/login/agent")
    public String loginAsAgent(@ModelAttribute("agent") Agent agent, RedirectAttributes ra) {
        Agent agentLogin = agentRepository.findByUsernameAndPassword(agent.getUsername(), agent.getPassword());

        try {
            if (agentLogin == null) {
                return "loginagent";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        ra.addFlashAttribute("agentlogin", agentLogin);
        return "redirect:/agent/homepage";
    }
}
