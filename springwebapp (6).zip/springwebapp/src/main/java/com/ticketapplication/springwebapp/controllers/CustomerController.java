package com.ticketapplication.springwebapp.controllers;

import com.ticketapplication.springwebapp.models.Application;
import com.ticketapplication.springwebapp.models.Customer;
import com.ticketapplication.springwebapp.models.Ticket;
import com.ticketapplication.springwebapp.repositories.ApplicationRepository;
import com.ticketapplication.springwebapp.repositories.CustomerRepository;
import com.ticketapplication.springwebapp.repositories.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Date;
import java.util.Set;

@Controller
public class CustomerController {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @GetMapping("/homepage")
    public String displayHomepageCustomer(Model model,
                                          @ModelAttribute("customerlogin") Object customerlogin,
                                          @RequestParam(required = false) Long customerId) {

        if (customerId != null) {
            Customer customer = customerRepository.findById(customerId)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid customer Id:" + customerId));
            model.addAttribute("customerlogin", customer);
        } else {
            model.addAttribute("customerlogin", customerlogin);
        }

        model.addAttribute("apps", applicationRepository.findAll());
        return "homepage";
    }

    @GetMapping("/mytickets")
    public String displayAllTicketsCustomer(@RequestParam Long customerId,
                                            Model model) {

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid customer Id:" + customerId));

        Set<Ticket> tickets = customer.getTickets();

        model.addAttribute("customerlogin", customer);
        model.addAttribute("tickets", tickets);
        return "mytickets";
    }

    @GetMapping("/buy/ticket")
    public String buyTicket(@RequestParam Long customerId,
                            @RequestParam Long applicationId,
                            RedirectAttributes ra) {
        Ticket ticket = new Ticket();

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid customer Id:" + customerId));

        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid application Id:" + applicationId));

        ticket.setCustomer(customer);
        ticket.setApplication(application);
        ticket.setDate(new Date());
        ticket.setTitle("Ticket " + (int)(Math.random()*100));
        ticket.setDescription("Ticket for " + application.getName());
        ticketRepository.save(ticket);

        customer.getTickets().add(ticket);
        customerRepository.save(customer);

        ra.addFlashAttribute("customerlogin", customer);
        return "redirect:/homepage";
    }
}
