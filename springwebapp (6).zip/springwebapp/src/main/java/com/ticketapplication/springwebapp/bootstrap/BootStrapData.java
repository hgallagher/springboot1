package com.ticketapplication.springwebapp.bootstrap;

import com.ticketapplication.springwebapp.models.*;
import com.ticketapplication.springwebapp.repositories.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapData implements CommandLineRunner {

    private final AdminRepository adminRepository;
    private final ApplicationRepository applicationRepository;
    private final CustomerRepository customerRepository;
    private final TicketRepository ticketRepository;
    private final AgentRepository agentRepository;
    private final ManagerRepository managerRepository;

    public BootStrapData(AdminRepository adminRepository, ApplicationRepository applicationRepository, CustomerRepository customerRepository, TicketRepository ticketRepository, AgentRepository agentRepository, ManagerRepository managerRepository) {
        this.adminRepository = adminRepository;
        this.applicationRepository = applicationRepository;
        this.customerRepository = customerRepository;
        this.ticketRepository = ticketRepository;
        this.agentRepository = agentRepository;
        this.managerRepository = managerRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        // Admins
        Admin admin1 = new Admin("admin1", "12345");

        // Managers
        Manager manager1 = new Manager("manager1", "12345");
        Manager manager2 = new Manager("manager2", "12345");

        // Agents
        Agent agent1 = new Agent("agent1", "12345");
        Agent agent2 = new Agent("agent2", "12345");

        // Customers
        Customer customer1 = new Customer("customer1", "12345");
        Customer customer2 = new Customer("customer2", "12345");

        // Applications
        Application application1 = new Application("application1");
        Application application2 = new Application("application2");
        Application application3 = new Application("application3");

        // Add agents to manager
        manager1.getAgents().add(agent1);
        manager2.getAgents().add(agent2);

        // Add manager to agent
        agent1.setManager(manager1);
        agent2.setManager(manager2);

        // Save repositories
        adminRepository.save(admin1);

        managerRepository.save(manager1);
        managerRepository.save(manager2);

        agentRepository.save(agent1);
        agentRepository.save(agent2);

        applicationRepository.save(application1);
        applicationRepository.save(application2);
        applicationRepository.save(application3);

        customerRepository.save(customer1);
        customerRepository.save(customer2);

        System.out.println("Number of applications: " + applicationRepository.count());
        System.out.println("Number of tickets: " + ticketRepository.count());
        System.out.println("Number of customers: " + customerRepository.count());
        System.out.println("Number of managers: " + managerRepository.count());
        System.out.println("Number of agents: " + agentRepository.count());
    }
}
