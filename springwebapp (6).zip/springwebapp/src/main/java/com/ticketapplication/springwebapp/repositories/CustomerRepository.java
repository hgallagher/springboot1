package com.ticketapplication.springwebapp.repositories;

import com.ticketapplication.springwebapp.models.Customer;
import org.springframework.data.repository.CrudRepository;

public interface CustomerRepository extends CrudRepository<Customer, Long> {
    Customer findByUsernameAndPassword(String username, String password);
}
