package com.ticketapplication.springwebapp.models;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity

public class Agent{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long agentId;

    private String username;
    private String password;

    @OneToMany(mappedBy = "agent")
    private Set<Ticket> tickets = new HashSet<>();

    @ManyToOne
    @JoinColumn(name = "manager_id")
    private Manager manager;

    public Agent() {
    }

    public Agent(String username, String password, Manager manager) {
        this.username = username;
        this.password = password;
        this.manager = manager;
    }

    public Agent(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }

    public Set<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(Set<Ticket> tickets) {
        this.tickets = tickets;
    }

    public Long getAgentId() {
        return agentId;
    }

    public void setAgentId(Long agentId) {
        this.agentId = agentId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
